data <- read.csv('./total_result.csv')
goal_indicator <- 'g1'

communitys <- unique(data$community)
bellw_result <- data.frame(matrix(nrow = 0,ncol = ncol(data)))
colnames(bellw_result) <- colnames(data)
  
for (commu in communitys){
  subdata <- data[data$community==commu,]
  projects <- unique(subdata$target)
  for(holdout in projects){
    temp <- subdata[subdata$source!=holdout,]
    performanceWithoutHoldout <- temp[temp$target!=holdout,]
    groupBySource <- aggregate(performanceWithoutHoldout$g1, list(performanceWithoutHoldout$source), FUN=sum) 
    colnames(groupBySource) <- c('target','sum')
    bellwName <- groupBySource$target[which.max(groupBySource$sum)]
    bellw_result[nrow(bellw_result)+1,] <-  subdata[subdata$source==bellwName&subdata$target==holdout,]
  }
}

write.csv(bellw_result,'./bellw_result.csv',row.names = FALSE)





library(pROC)
start.time <- Sys.time()


SC <- function(A){
  # cat("# Normalize software metrics .\n")
  
  gc()
  normA = apply(A, 2, function(x){(x - mean(x))/sd(x)})
  normA = normA[,colSums(is.na(normA))==0]
  gc()
  # cat("# Construct the weighted adjacency matrix W.\n")
  
  
  W = normA %*% t(normA)
  # cat("# Set all negative values to zero .\n")
  W[W <0] = 0
  # cat("# Set the self - similarity to zero .\n")
  W = W - diag(diag(W))
  gc()
  # cat("# Construct the symmetric Laplacian matrix Lsym.\n")
  Dnsqrt = diag(1/sqrt(rowSums(W)))
  I = diag(rep(1, nrow(W)))
  gc()
  Lsym = I - Dnsqrt %*% W %*% Dnsqrt
  # cat("# Perform the eigendecomposition .\n")
  gc()
  ret_egn = eigen(Lsym, symmetric = TRUE)
  # cat("# Pick up the second smallest eigenvector .\n")
  gc()
  v1 = Dnsqrt %*% ret_egn $ vectors[, nrow(W)-1]
  v1 = v1 / sqrt(sum(v1^2))
  # cat("# Divide the data set into two clusters .\n")
  gc()
  
  predictedLabel = (v1 >0)
  # Label the defective and clean clusters .
  rs = rowSums(normA)
  if( mean(rs[v1>0]) < mean(rs[v1<0]))
    predictedLabel = (v1<0)
  
  result = cbind("predictedValue"=v1, "predictedLabel" = predictedLabel)
  
  # Return the defect proneness .
  return(result)
}

get_sloc <- function(data){
  if('loc' %in% colnames(data)){
    cn <- 'loc'
  }else if('LOC_EXECUTABLE' %in% colnames(data)){
    cn <- 'LOC_EXECUTABLE'
  }else if('numberOfLinesOfCode' %in% colnames(data)){
    cn <- 'numberOfLinesOfCode'
  }else if('CountLineCodeExe' %in% colnames(data)){
    cn <- 'CountLineCodeExe'
  }else if('LOC' %in% colnames(data)){
    cn <- 'LOC'
  }else if('sloc' %in% colnames(data)){
    cn <- 'sloc'
  }else if('SumnumChangedFiles' %in% colnames(data)){
    cn <- 'SumnumChangedFiles'
  }else if('current_LLOC' %in% colnames(data)){
    cn <- 'current_LLOC'
  }
  
  return(data[,cn])
}

get_indicators <- function(predictedValue,predictLabel,sloc,actualBugLabel,fileName){
  test <- cbind("predictedValue" = predictedValue, "predictLabel" = predictLabel, "sloc" = sloc, "actualBugLabel" = actualBugLabel)
  test <- data.frame(test)
  
  flag <- sum(test[test[,"predictLabel"]==TRUE,"predictedValue"])
  # if(flag < 0){
  #   test <- test[with(test, order(-predictLabel, predictedValue,sloc,actualBugLabel)), ]
  # }else{
  #   test <- test[with(test, order(-predictLabel, -predictedValue,sloc,actualBugLabel)), ]
  # }
  test <- test[with(test, order(-predictLabel, sloc, actualBugLabel)), ]
  
  write.csv(test,paste('./result/SC_',strsplit(fileName,'/')[[1]][length(strsplit(fileName,'/')[[1]])],sep = ''))
  
  sloc.cumsum <- cumsum(test[,'sloc'])
  
  tp <- 0
  fp <- 0
  tn <- 0
  fn <- 0
  SNM_precision <- 0
  SNM_recall <- 0
  SNM_fscore <- 0
  SNM_fpr <- 0
  SNM_ifa <- 0
  SNM_ap <- 0
  SNM_rr <- 0
  SNM_cr <- 0
  SNM_roi <- 0
  SNM_mcc <- 0
  SNM_ifap <- 0
  
  tp20 <- 0
  fp20 <- 0
  tn20 <- 0
  fn20 <- 0
  SSC_precision <- 0
  SSC_recall <- 0
  SSC_fscore <- 0
  SSC_fpr <- 0
  SSC_ifa <- 0
  SSC_ap <- 0
  SSC_rr <- 0
  SSC_pii <- 0
  SSC_roi <- 0
  SSC_mcc <- 0
  SSC_ifap <- 0
  SSC_rcr <- 0
  
  counter <- 1
  counter_SNM <- 0
  flag_ifa <- -1
  
  for( i in rownames(test) ){
    if(flag_ifa==-1 && test[i, "predictLabel"]==1 && test[i, "actualBugLabel"]==1){
      flag_ifa <- 0
      SSC_ifa <- SNM_ifa <- counter - 1
      SSC_rr <- SNM_rr <- 1.0 / (counter - 1 + 1)
      SSC_pii_ifa <- SNM_pii_ifa <- SSC_ifa / nrow(test)
      
      if (counter==1){
        SSC_cr_ifa <- SNM_cr_ifa  <- 0
      }
      else{
        SSC_cr_ifa <- SNM_cr_ifa <-  sloc.cumsum[counter-1] / sloc.cumsum[length(sloc.cumsum)]
      }
      SSC_ifap <- SNM_ifap <- SSC_cr_ifa * SSC_pii_ifa
    }
    
    if(test[i, "predictLabel"]==0 && test[i, "actualBugLabel"]==0){
      tn <- tn + 1
    }
    if(test[i, "predictLabel"]==0 && test[i, "actualBugLabel"]==1){
      fn <- fn + 1
    }
    if(test[i, "predictLabel"]==1 && test[i, "actualBugLabel"]==0){
      fp <- fp + 1
    }
    if(test[i, "predictLabel"]==1 && test[i, "actualBugLabel"]==1){
      tp <- tp + 1
    }
    if(test[i, "predictLabel"]==1 ){
      counter_SNM <- counter_SNM + 1
    }
    
    if(sloc.cumsum[counter] <= sloc.cumsum[length(sloc.cumsum)] * 0.2 && test[i, "actualBugLabel"]==1){
      tp20 <- tp20 + 1
    }
    if(sloc.cumsum[counter] <= sloc.cumsum[length(sloc.cumsum)] * 0.2 && test[i, "actualBugLabel"]==0){
      fp20 <- fp20 + 1
    }
    if(sloc.cumsum[counter] > sloc.cumsum[length(sloc.cumsum)] * 0.2 && test[i, "actualBugLabel"]==1){
      fn20 <- fn20 + 1
    }
    if(sloc.cumsum[counter] > sloc.cumsum[length(sloc.cumsum)] * 0.2 && test[i, "actualBugLabel"]==0){
      tn20 <- tn20 + 1
    }
    if(sloc.cumsum[counter] <= sloc.cumsum[length(sloc.cumsum)] * 0.2){
      SSC_rcr <- sloc.cumsum[counter]
      SSC_ap <- SSC_ap + (tp20 / (tp20 + fp20))
    }
    if(test[i, "predictLabel"]==1){
      SNM_ap <- SNM_ap + (tp / (tp + fp))
    }
    counter <- counter + 1
  }
  
  SSC_ap <- SSC_ap / (tp20 + fp20)
  SSC_rcr <- SSC_rcr / (sloc.cumsum[length(sloc.cumsum)] * 0.2)
  
  SSC_pii <- (tp20 + fp20) / (tp20 + fp20 + tn20 + fn20)
  SSC_recall <- tp20 / (tp20 + fn20)
  SSC_precision <- tp20 / (tp20 + fp20)
  SSC_fpr <- fp20 / (fp20 + tn20)
  SSC_fscore <- 2*SSC_recall*SSC_precision/(SSC_recall + SSC_precision)
  SSC_roi <- SSC_recall / (SSC_pii*SSC_rcr)
  
  SSC_mcc <- (tp20 * tn20 - fp20 * fn20) / sqrt((tp20 + fp20) * (tp20 + fn20) * (tn20 + fp20) * (tn20 + fn20))
  
  SNM_ap <- SNM_ap / (tp + fp)
  SNM_cr <- sloc.cumsum[counter_SNM] / sloc.cumsum[length(sloc.cumsum)]
  SNM_recall <- tp / (tp + fn)
  SNM_precision <- tp / (tp + fp)
  SNM_fpr <- fp / (fp + tn)
  SNM_fscore <- 2*SNM_recall*SNM_precision/(SNM_recall + SNM_precision)
  SNM_roi <- SNM_recall / SNM_cr
  SNM_mcc <- (tp * tn - fp * fn) / sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
  
  return(c(tp,fp,tn,fn,SNM_precision,SNM_recall,SNM_fscore,SNM_fpr,SNM_ifa,SNM_ap,SNM_rr,SNM_cr,SNM_roi,SNM_mcc,SNM_ifap,SNM_cr_ifa,SNM_pii_ifa,tp20,fp20,tn20,fn20,SSC_precision,SSC_recall,SSC_fscore,SSC_fpr,SSC_ifa,SSC_ap,SSC_rr,SSC_pii,SSC_roi,SSC_mcc,SSC_ifap,SSC_cr_ifa,SSC_pii_ifa,SSC_rcr))
}

processOneData<-function(fileName){
  data <- read.csv(fileName)
  lastNo <- ncol(data)
  metricData <- data[,-lastNo]
  actualBugLabel <- data[,lastNo]
  
  # cat("before SC(metricData)...\n")
  temp <- SC(metricData)
  # cat("after SC(metricData)...\n")
  
  predictedValue <- temp[,1] 
  predictLabel <- temp[,2]*1
  sloc <- get_sloc(data)
  
  TP <- sum(predictLabel * actualBugLabel)
  FP <- sum(predictLabel - predictLabel * actualBugLabel)
  TN <- sum((1-predictLabel) * (1-actualBugLabel))
  FN <- nrow(data) - TP - FP - TN
  
  Recall <- TP / (TP + FN)
  Precision <- TP / (TP + FP)
  PF <- FP / (FP + TN)
  
  F1 <- 2*Recall*Precision / (Recall + Precision)
  G1 <- 2*Recall*(1-PF) / (Recall + 1 - PF)
  G2 <- sqrt(Recall * Precision)
  G3 <- sqrt(Recall * (1-PF))
  MCC <- (TP*TN - FP*FN) / sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))
  AUC <- auc(actualBugLabel, predictedValue)
  
  line <- ""
  indicators <- get_indicators(predictedValue,predictLabel,sloc,actualBugLabel,fileName = fileName)
  for (indicator in indicators) {
    # cat(indicator,'\n')
    line <- paste(line,",",toString(indicator))
  }
  
  oneElem <- paste(fileName,",cpdp,SC,",TP,",",FP,",",TN,",",FN,",",F1,line,collapse="")
  
  # cat("TP,FP,TN,FN,F1,G1,G2,G3,MCC,AUC\n")
  # oneElem<-paste(fileName,",cpdp,SC,",TP,",",FP,",",TN,",",FN,",",F1,",",G1,",",G2,",",G3,",",MCC,",",AUC,collapse="")
  # oneElem<-paste(fileName,",cpdp,SC,",TP,",",FP,",",TN,",",FN,",",F1,",",G1,",",G2,",",G3,",",MCC,",",AUC,collapse="")
  
  cat(oneElem)
  cat("\n")  
}

for(i in 1:1){
  start.time <- Sys.time()
  cat(start.time,"\n")
  # setwd("D:\\OneDrive - Microsoft Student Partners\\OneDrive - Student Ambassadors\\UCS2\\UCS\\unsupervised\\SC")
  fileNames <- list.files('./data/',full.names = TRUE)
  sink('./outlog01061400.csv')
  cat("Test,Scenario,Model,TP,FP,TN,FN,F1,tp,fp,tn,fn,SNM_precision,SNM_recall,SNM_fscore,SNM_fpr,SNM_ifa,SNM_ap,SNM_rr,SNM_cr,SNM_roi,SNM_mcc,SNM_ifap,SNM_cr_ifa,SNM_pii_ifa,tp20,fp20,tn20,fn20,SSC_precision,SSC_recall,SSC_fscore,SSC_fpr,SSC_ifa,SSC_ap,SSC_rr,SSC_pii,SSC_roi,SSC_mcc,SSC_ifap,SSC_cr_ifa,SSC_pii_ifa,SSC_rcr\n")
  for(fileName in fileNames){
    cat(fileName)
    # if(fileName=='./data/MDP-PC5.csv'){
    #   next
    # }
    processOneData(fileName)
  }
  
  closeAllConnections()
  
  result.files <- list.files("result",full.names = TRUE,pattern = '*.csv')
  for (file in result.files){
    data.frame()
    data <- read.csv(file)
    data <- data[with(data, order(X)), ]
    data$X <- NULL
    write.csv(data,file,row.names = FALSE,quote = FALSE)
  }
  
  
  end.time <- Sys.time()
  time.taken <- end.time - start.time
  
  
  diff.time <- as.numeric(time.taken, units = "secs")
  time_log <-file("time_log_SC.txt")
  write(as.character(diff.time),file="time_log_SC.txt",append=TRUE)
  close(time_log)
  
}
